# @liqweb/mcp-server-jira

A **secure MCP server** for [Jira](https://www.atlassian.com/software/jira) that
integrates with VS Code, GitHub Copilot, Claude Desktop, and any MCP-compatible
AI client.

Supports **Jira Data Center / Server** (Bearer PAT).

> **Jira Cloud users:** Use the official [Atlassian Rovo MCP](https://www.atlassian.com/platform/rovo) instead.

## Features

- **Search issues** with JQL
- **Get issue** details by key
- **Create / update** issues
- **Transition** issues through workflows
- **Assign** issues to users
- **Add comments** to issues
- **List projects** accessible to the authenticated user
- **Resource access** via `jira://issue/{key}` URIs

---

## Installation

### Option A — Install globally from the local package

```bash
# Build and pack
cd /path/to/JiraMCP
npm run build
npm pack

# Install globally from the generated tarball
npm install -g ./liqweb-mcp-server-jira-1.0.0.tgz
```

Verify:

```bash
mcp-server-jira --help
```

### Option B — Link for active development (no reinstall needed after edits)

```bash
cd /path/to/JiraMCP
npm run build
npm link
```

> Re-run `npm run build` after any source change; the symlink picks up the new `dist/` automatically.

---

## Credentials Setup

Credentials are loaded from a file on disk — **never passed as inline env vars or committed to source control**.

### 1. Create `~/.jira-mcp.env`

**Jira Data Center / Server (PAT — Bearer token)**

```env
JIRA_URL=https://your-jira.example.com
JIRA_AUTH_TYPE=bearer
JIRA_PAT=<paste raw PAT from your Jira profile page>
```

Getting a Data Center PAT:
1. Log in to your Jira instance
2. Click your avatar → **Profile** → **Personal Access Tokens**
3. Click **Create token**, give it a name, copy the value
4. Paste the raw token as `JIRA_PAT` — **do not base64-encode it**

### 2. (Optional) Use a custom credentials file path

Set `JIRA_ENV_FILE` to point to any file:

```env
JIRA_ENV_FILE=C:/Users/you/secrets/jira.env
```

---

## VS Code MCP Configuration

### Global config (`%APPDATA%\Code\User\mcp.json` on Windows, `~/.config/Code/User/mcp.json` on Linux/macOS)

```jsonc
{
  "servers": {
    "jira": {
      "type": "stdio",
      "command": "mcp-server-jira",
      "env": {
        "JIRA_ENV_FILE": "C:/Users/<you>/.jira-mcp.env"
      }
    }
  }
}
```

### Workspace config (`.vscode/mcp.json` — shared with the team)

```jsonc
{
  "servers": {
    "jira": {
      "type": "stdio",
      "command": "mcp-server-jira",
      "env": {
        "JIRA_ENV_FILE": "${env:USERPROFILE}/.jira-mcp.env"
      }
    }
  }
}
```

> Each team member provides their own `~/.jira-mcp.env`. The workspace config contains no secrets.

After any config change: `Ctrl+Shift+P` → **MCP: List Servers** → select `jira` → **Restart**.

---

## Available Tools

| Tool | Description |
|------|-------------|
| `jira_search_issues` | Search issues with JQL |
| `jira_get_issue` | Get issue details by key |
| `jira_create_issue` | Create a new issue |
| `jira_update_issue` | Update issue fields |
| `jira_transition_issue` | Move issue through workflow |
| `jira_assign_issue` | Assign issue to a user |
| `jira_add_comment` | Add a comment to an issue |
| `jira_list_projects` | List accessible projects |
| `jira_get_transitions` | Get available workflow transitions |

---

## Security

- Credentials loaded from a file — never hardcoded or passed as inline env vars
- HTTPS enforced for all Jira URLs (HTTP only allowed for `localhost`)
- All tool inputs validated with Zod schemas
- No `eval()`, no dynamic code execution
- Minimal dependencies (MCP SDK + Zod only)
- 30-second request timeouts
- 1MB request body cap, 10MB response cap (CWE-400 defence)
- SSRF warning for private/internal IP addresses

---

## Development

```bash
npm install
npm run build       # compile TypeScript → dist/
npm link            # register binary globally for local testing
```

---

## License

MIT
